`timescale 1ns/1ps
module tb_keypad;
reg kf=0;
always #50 kf=~kf;
reg reset=0;
reg [3:0] pressed=0;
reg [1:0] ki;
wire [1:0] ko;
wire [4:0] kn,kv;
wire [7:0] kascii;
wire kok,koo;
integer errors=0,checks=0,keynum,timeout;
reg [4:0] expected_kn;
k4x4 dut(.kf(kf),.reset(reset),.ki(ki),.ko(ko),.kn(kn),.kv(kv),.kascii(kascii),.kok(kok),.koo(koo));
always @* begin
 ki=2'b11;
 if(pressed[0] && ko[0]===0) ki[0]=0;
 if(pressed[1] && ko[1]===0) ki[0]=0;
 if(pressed[2] && ko[0]===0) ki[1]=0;
 if(pressed[3] && ko[1]===0) ki[1]=0;
end
task check;
 input ok;
 input [511:0] message;
 begin
  checks=checks+1;
  if(ok!==1'b1) begin errors=errors+1;$display("FAIL %0s kn=%d kv=%d",message,kn,kv);end
 end
endtask
initial begin
 if($test$plusargs("vcd")) begin $dumpfile("keypad.vcd");$dumpvars(0,tb_keypad);end
 #1;reset=1;#1;reset=0;
 #10;check(kn===0 && ko===2'b10 && koo===0,"asynchronous reset");
 @(negedge kf);reset=1;
 repeat(500) begin @(negedge kf);check(kn<16,"scan stays within ROM bounds");check(kok===0,"no phantom key");end
 for(keynum=0;keynum<4;keynum=keynum+1) begin
  pressed=1<<keynum;
  timeout=0;
  while(kok!==1 && timeout<300) begin @(negedge kf);timeout=timeout+1;end
  check(kok===1,"key recognized");
  case(keynum) 0:expected_kn=0;1:expected_kn=1;2:expected_kn=4;3:expected_kn=5;endcase
  check(kn===expected_kn,"key scan index");
  check(kv===keynum,"key mapped value");
  check(kascii==8'h30+keynum,"key ASCII");
  pressed=0;
  repeat(250) @(negedge kf);
 end
 // Short bounce must not reach the acceptance count.
 reset=0;#1;reset=1;pressed=1;
 repeat(1) @(negedge kf);
 pressed=0;
 repeat(30) begin @(negedge kf);check(kok===0,"short key bounce rejected");end
 $display("KEYPAD_RESULT checks=%0d errors=%0d",checks,errors);
 if(errors) $fatal(1,"keypad simulation failed");
 $display("KEYPAD PASS");$finish;
end
initial begin #1000000;$fatal(1,"keypad timeout");end
endmodule
