`timescale 1ns/1ps
module tb_uart;
reg clk=0;
always #10 clk=~clk;
reg reset=0;
reg [1:0] dl=3, stopn=0;
reg [2:0] parityn=0;
reg [3:0] f_set=11;
reg tx_w=0, rx_r=0, rd=1;
reg [7:0] txdata=0;
wire tx;
wire [1:0] tx_status;
wire [2:0] rx_status;
wire [9:0] rx_bbn;
wire [7:0] rxds;
integer checks=0;
integer errors=0;
integer rates[0:15];
integer rate;
integer mode;
integer i;
reg [7:0] value;
realtime bit_ns;
rs232_t4 transmitter(.clk(clk),.reset(reset),.dl(dl),.parityn(parityn),
 .stopn(stopn),.f_set(f_set),.status_s(tx_status),.tx_w(tx_w),.txdata(txdata),.tx(tx));
rs232_r4 receiver(.clk(clk),.reset(reset),.dl(dl),.parityn(parityn),
 .stopn(stopn),.f_set(f_set),.status_s(rx_status),.rx_bbn(rx_bbn),.rx_r(rx_r),.rd(rd),.rxds(rxds));

task check;
 input ok;
 input [511:0] message;
 begin
  checks=checks+1;
  if(ok!==1'b1) begin
   errors=errors+1;
   $display("FAIL rate=%0d dl=%0d parity=%b time=%0t: %0s",rates[f_set],dl,parityn,$time,message);
   $fflush();
  end
 end
endtask

task do_reset;
 begin
  @(negedge clk); reset=0; tx_w=0; rx_r=0; rd=1;
  repeat(10) @(negedge clk);
  check(tx===1'b1,"TX idle during reset");
  check(rx_bbn===0,"RX count during reset");
  reset=1;
  repeat(10) @(negedge clk);
 end
endtask

task write_tx;
 input [7:0] data;
 begin
  @(negedge clk); txdata=data; tx_w=1;
  wait(tx_status[1]===1'b1);
  @(negedge clk); tx_w=0;
  wait(tx_status[1]===1'b0);
 end
endtask

function parity_bit;
 input [7:0] data;
 input integer n;
 integer j;
 reg p;
 begin
  p=parityn[0];
  if(parityn[1]===0) for(j=0;j<n;j=j+1) p=p^data[j];
  parity_bit=p;
 end
endfunction

task decode_tx;
 input [7:0] data;
 integer j;
 integer n;
 begin
  n=dl+5;
  @(negedge tx);
  #(bit_ns/2.0);
  check(tx===0,"TX start bit");
  for(j=0;j<n;j=j+1) begin
   #(bit_ns);
   check(tx===data[j],"TX data bit");
  end
  if(parityn[2]) begin
   #(bit_ns);
   check(tx===parity_bit(data,n),"TX parity bit");
  end
  #(bit_ns);
  check(tx===1,"TX stop bit");
  #(bit_ns*0.25);
  check(tx===1,"TX idle after frame");
 end
endtask

task send_rx;
 input [7:0] data;
 input corrupt_parity;
 integer j;
 integer n;
 begin
  n=dl+5;
  rd=0; #(bit_ns);
  for(j=0;j<n;j=j+1) begin rd=data[j]; #(bit_ns); end
  if(parityn[2]) begin rd=parity_bit(data,n)^corrupt_parity; #(bit_ns); end
  rd=1;
  case(stopn)
   2: #(bit_ns*2);
   3: #(bit_ns*1.5);
   default: #(bit_ns);
  endcase
 end
endtask

task read_rx;
 input [7:0] expected;
 input parity_error;
 integer timeout;
 begin
  timeout=0;
  while(rx_status[2]!==1 && timeout<200) begin @(negedge clk); timeout=timeout+1; end
  check(rx_status[2]===1,"RX data available");
  check(rxds===expected,"RX data value");
  check(rx_status[1]===parity_error,"RX parity status");
  check(rx_bbn!==0,"RX count before acknowledge");
  @(posedge clk); #1 rx_r=1;
  @(posedge clk); #1 rx_r=0;
  repeat(5) @(posedge clk);
 end
endtask

initial begin
 rates[0]=300;rates[1]=600;rates[2]=1200;rates[3]=2400;
 rates[4]=4800;rates[5]=9600;rates[6]=19200;rates[7]=28800;
 rates[8]=38400;rates[9]=57600;rates[10]=76800;rates[11]=115200;
 rates[12]=230400;rates[13]=460800;rates[14]=576000;rates[15]=921600;
 if($test$plusargs("vcd")) begin $dumpfile("uart.vcd"); $dumpvars(1,tb_uart); end
 // Highest rate first: catches accumulated divider errors quickly.
 for(rate=15;rate>=0;rate=rate-1) begin
  f_set=rate; bit_ns=1.0e9/rates[rate]; dl=3; parityn=0;stopn=0;
  do_reset;
  fork
   write_tx(8'hA5);
   decode_tx(8'hA5);
   begin send_rx(8'h96,0); read_rx(8'h96,0); end
  join
  check(rx_bbn===0,"RX empty after acknowledge");
  $display("RATE_COMPLETE %0d",rates[rate]);
  $fflush();
  if(errors!=0 && $test$plusargs("failfast")) $fatal(1,"rate test failed");
 end
 // 5/6/7/8 data bits, all parity modes, all stop settings.
 f_set=11;bit_ns=1.0e9/rates[11];
 for(mode=0;mode<20;mode=mode+1) begin
  dl=mode%4;
  case(mode/4) 0:parityn=0;1:parityn=4;2:parityn=5;3:parityn=6;4:parityn=7; endcase
  stopn=mode%4;
  value=8'hA5 & (8'hff>>(3-dl));
  do_reset;
  fork
   write_tx(value);
   decode_tx(value);
   begin send_rx(value,0);read_rx(value,0);end
  join
 end
 // Deliberately incorrect even parity.
 dl=3;parityn=4;stopn=0;do_reset;
 send_rx(8'h53,1);read_rx(8'h53,1);
 // FIFO: three consecutive frames must remain in order.
 parityn=0;do_reset;
 for(i=0;i<3;i=i+1) send_rx(8'h20+i,0);
 check(rx_bbn===3,"RX FIFO queued count");
 for(i=0;i<3;i=i+1) read_rx(8'h20+i,0);
 check(rx_bbn===0,"RX FIFO drained count");
 // TX FIFO: queue ahead while decoding at the nominal line rate.
 do_reset;
 fork
  begin write_tx(8'h12);write_tx(8'hA5);write_tx(8'hFE);end
  begin decode_tx(8'h12);decode_tx(8'hA5);decode_tx(8'hFE);end
 join
 // Exercise alternating/all-zero/all-one data at the highest baud rate.
 f_set=15;bit_ns=1.0e9/rates[15];
 for(mode=0;mode<4;mode=mode+1) begin
  case(mode) 0:value=0;1:value=8'hFF;2:value=8'h55;3:value=8'hAA;endcase
  do_reset;
  fork
   write_tx(value);
   decode_tx(value);
   begin send_rx(value,0);read_rx(value,0);end
  join
 end
 // Reset while a frame is active.
 fork
  write_tx(8'h55);
  begin @(negedge tx); #(bit_ns*2); reset=0; #100;check(tx===1,"reset interrupts TX frame"); end
 join
 check(rx_bbn===0,"reset clears RX FIFO");
 $display("UART_RESULT checks=%0d errors=%0d",checks,errors);
 if(errors) $fatal(1,"UART simulation failed");
 $display("UART PASS");$finish;
end
initial begin #200000000; $fatal(1,"simulation timeout"); end
initial begin if($test$plusargs("vcd")) begin #200000; $dumpoff; end end
endmodule
