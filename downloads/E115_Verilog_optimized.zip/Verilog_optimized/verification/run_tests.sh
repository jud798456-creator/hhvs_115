#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build logs waveforms
for bench in tb_keypad tb_uart; do
    iverilog -g2005 -Wall -s "$bench" -o "build/$bench.vvp" ../E115_uart_keypad_fixed.v "tests/$bench.v"
    (cd waveforms && vvp "../build/$bench.vvp" +vcd) | tee "logs/$bench.log"
done
