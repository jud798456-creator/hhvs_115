`timescale 1ns/1ps

// 50 MHz clock; f_set selects 300 .. 921600 baud.
// reset is active low. Public interfaces match the original project.

module k4x4 (
    input kf, reset,
    input [1:0] ki,
    output [1:0] ko,
    output reg [4:0] kn,
    output reg [4:0] kv,
    output reg [7:0] kascii,
    output kok,
    output reg koo
);
    reg [3:0] columns;
    reg [7:0] debounce;
    wire [3:0] rows = {2'b11, ki};

    assign ko = columns[1:0];
    assign kok = (debounce == 8'd20);

    always @* begin
        case (kn)
            5'd0: kv = 5'd0;
            5'd1: kv = 5'd1;
            5'd4: kv = 5'd2;
            5'd5: kv = 5'd3;
            default: kv = 5'd16;
        endcase
        case (kn)
            5'd0: kascii = 8'h30;
            5'd1: kascii = 8'h31;
            5'd2, 5'd4: kascii = 8'h32;
            5'd3, 5'd5: kascii = 8'h33;
            5'd6: kascii = 8'h35;
            5'd7, 5'd9: kascii = 8'h37;
            5'd8: kascii = 8'h36;
            5'd10: kascii = 8'h38;
            default: kascii = {3'b000, kn};
        endcase
    end

    always @(posedge kf or negedge reset) begin
        if (!reset) begin
            kn <= 5'd0;
            columns <= 4'b1110;
            debounce <= 8'd0;
            koo <= 1'b0;
        end else if (debounce == 8'd200) begin
            kn <= 5'd0;
            columns <= 4'b1110;
            debounce <= 8'd0;
        end else if (debounce != 0) begin
            if (rows == 4'b1111 && (debounce < 2 || debounce > 25))
                debounce <= 8'd200;
            else
                debounce <= debounce + 1'b1;
        end else if (!rows[kn[3:2]]) begin
            debounce <= 8'd1;
            koo <= ~koo;
        end else begin
            columns <= {columns[2:0], columns[3]};
            if (kn == 5'd15) begin
                kn <= 5'd0;
                debounce <= 8'd200;
            end else begin
                kn <= kn + 1'b1;
            end
        end
    end
endmodule

// Shared fractional divider: four quarter-bit periods form one UART bit.
module e115_uart_baud #(parameter RESET_LEVEL = 1'b0) (
    input clk, reset,
    input [3:0] f_set,
    output reg baud_clock
);
    reg [15:0] divider;
    reg [1:0] phase;
    reg [15:0] period;

    always @* begin
        case (f_set)
            4'd0:  period = (phase == 3) ? 16'd41666 : 16'd41667;
            4'd1:  period = (phase == 1) ? 16'd20834 : 16'd20833;
            4'd2:  period = (phase == 0) ? 16'd10416 : 16'd10417;
            4'd3:  period = (phase == 1) ? 16'd5209 : 16'd5208;
            4'd4:  period = (phase == 1) ? 16'd2605 : 16'd2604;
            4'd5:  period = 16'd1302;
            4'd6:  period = 16'd651;
            4'd7:  period = 16'd434;
            4'd8:  period = (phase == 0 || phase == 3) ? 16'd325 : 16'd326;
            4'd9:  period = 16'd217;
            4'd10: period = (phase == 0) ? 16'd162 : 16'd163;
            4'd11: period = (phase == 1) ? 16'd109 : 16'd108;
            4'd12: period = (phase == 1) ? 16'd55 : 16'd54;
            4'd13: period = (phase == 2) ? 16'd28 : 16'd27;
            4'd14: period = (phase == 0) ? 16'd21 : 16'd22;
            4'd15: period = (phase == 0 || phase == 3) ? 16'd13 : 16'd14;
            default: period = 16'd41667;
        endcase
    end

    always @(posedge clk or negedge reset) begin
        if (!reset) begin
            divider <= 16'd0;
            phase <= 2'd0;
            baud_clock <= RESET_LEVEL;
        end else if (divider == period - 16'd1) begin
            divider <= 16'd0;
            phase <= phase + 1'b1;
            baud_clock <= ~baud_clock;
        end else begin
            divider <= divider + 1'b1;
        end
    end
endmodule

module rs232_t4 #(parameter txrd_buff = 511) (
    input clk, reset,
    input [1:0] dl,
    input [2:0] parityn,
    input [1:0] stopn,
    input [3:0] f_set,
    output [1:0] status_s,
    input tx_w,
    input [7:0] txdata,
    output reg tx
);
    generate if (txrd_buff != 511) begin : unsupported_buffer
        BUFFER_SIZE_MUST_BE_511 regenerate_for_other_sizes();
    end endgenerate

    localparam PTR_W = (txrd_buff < 1) ? 1 : $clog2(txrd_buff + 1);
    localparam COUNT_W = $clog2(txrd_buff + 2);
    localparam [PTR_W-1:0] LAST = txrd_buff;
    localparam [2:0] IDLE = 3'd0, DATA = 3'd1, STOP = 3'd3;

    reg [7:0] fifo [0:txrd_buff];
    reg [PTR_W-1:0] read_ptr, write_ptr;
    reg [COUNT_W-1:0] count;
    reg write_ack, overflow, byte_ready, ready_at_clock, clear_byte;
    reg [7:0] next_byte, shift_data;
    reg [2:0] state;
    reg [3:0] bit_count;
    reg parity_bit, half_bit;
    wire baud_clock;
    wire [3:0] data_bits = {2'b00, dl} + 4'd5;
    wire [2:0] stop_state = (stopn == 2'b10) ? 3'd5 :
                            (stopn == 2'b11) ? 3'd6 : 3'd7;
    wire fetch_byte = state == IDLE && count != 0 &&
                      count < txrd_buff + 2 && !byte_ready;
    wire write_fifo = !(count > 512 && !write_ack) &&
                      !clear_byte && !fetch_byte && tx_w && !write_ack;

    assign status_s = {write_ack, overflow};
    e115_uart_baud baud(clk, reset, f_set, baud_clock);

    // Keep RAM writes clocked independently of asynchronous reset.
    always @(posedge clk) begin
        if (reset && write_fifo) fifo[write_ptr] <= txdata;
    end

    // FIFO and host write handshake; the pending byte has priority.
    always @(posedge clk or negedge reset) begin
        if (!reset) begin
            read_ptr <= 0;
            write_ptr <= 0;
            count <= 0;
            byte_ready <= 1'b0;
            ready_at_clock <= 1'b0;
            write_ack <= 1'b0;
            overflow <= 1'b0;
        end else begin
            // Use the value before this edge when the divided clock also rises.
            ready_at_clock <= byte_ready;
            if (count > 512 && !write_ack) begin
                write_ack <= 1'b1;
                overflow <= 1'b1;
            end else if (clear_byte) begin
                byte_ready <= 1'b0;
            end else if (fetch_byte) begin
                next_byte <= fifo[read_ptr];
                read_ptr <= (read_ptr == LAST) ? {PTR_W{1'b0}} : read_ptr + 1'b1;
                byte_ready <= 1'b1;
                count <= count - 1'b1;
            end else if (tx_w && !write_ack) begin
                write_ptr <= (write_ptr == LAST) ? {PTR_W{1'b0}} : write_ptr + 1'b1;
                count <= count + 1'b1;
                write_ack <= 1'b1;
            end else if (write_ack) begin
                if (!tx_w) write_ack <= 1'b0;
            end else if (count < 513) begin
                write_ack <= 1'b0;
                overflow <= 1'b0;
            end
        end
    end

    // One baud_clock rising edge represents half a serial bit.
    always @(posedge baud_clock or negedge reset) begin
        if (!reset) begin
            state <= IDLE;
            tx <= 1'b1;
            clear_byte <= 1'b0;
        end else if (state == IDLE && ready_at_clock) begin
            shift_data <= next_byte;
            tx <= 1'b0;
            bit_count <= 4'd0;
            parity_bit <= parityn[0];
            clear_byte <= 1'b1;
            half_bit <= 1'b0;
            state <= DATA;
        end else if (state != IDLE) begin
            clear_byte <= 1'b0;
            half_bit <= ~half_bit;
            case (state)
                DATA: if (half_bit) begin
                    if (bit_count == data_bits) begin
                        tx <= parityn[2] ? parity_bit : 1'b1;
                        state <= parityn[2] ? 3'd2 : stop_state;
                    end else begin
                        if (!parityn[1]) parity_bit <= parity_bit ^ shift_data[0];
                        tx <= shift_data[0];
                        shift_data <= {shift_data[0], shift_data[7:1]};
                        bit_count <= bit_count + 1'b1;
                    end
                end
                STOP: begin
                    state <= stop_state;
                    tx <= 1'b1;
                end
                default: state <= state + 1'b1;
            endcase
        end
    end
endmodule

module rs232_r4 #(parameter txrd_buff = 511) (
    input clk, reset,
    input [1:0] dl,
    input [2:0] parityn,
    input [1:0] stopn,
    input [3:0] f_set,
    output [2:0] status_s,
    output reg [$clog2(txrd_buff + 2)-1:0] rx_bbn,
    input rx_r, rd,
    output reg [7:0] rxds
);
    generate if (txrd_buff != 511) begin : unsupported_buffer
        BUFFER_SIZE_MUST_BE_511 regenerate_for_other_sizes();
    end endgenerate

    localparam PTR_W = (txrd_buff < 1) ? 1 : $clog2(txrd_buff + 1);
    localparam [PTR_W-1:0] LAST = txrd_buff;
    localparam [1:0] IDLE = 2'b00, RECEIVE = 2'b01, WAIT_HIGH = 2'b11;

    reg [7:0] fifo [0:txrd_buff];
    reg [txrd_buff:0] parity_errors, overruns;
    reg [PTR_W-1:0] read_ptr, write_ptr;
    reg data_ready, parity_error, overrun;
    reg upload, upload_seen;
    reg [1:0] state;
    reg [7:0] shift_data;
    reg [3:0] bit_count;
    reg half_bit, parity_bit;
    reg [7:0] received_byte;
    wire idle = (state[0] == state[1]);
    wire baud_reset = reset && !idle;
    wire baud_clock;
    wire receive_clock = idle ? clk : baud_clock;
    wire [3:0] frame_bits = {2'b00, dl} + 4'd6;

    assign status_s = {data_ready, parity_error, overrun};
    e115_uart_baud #(.RESET_LEVEL(1'b1)) baud(clk, baud_reset, f_set, baud_clock);

    always @(negedge clk) begin
        if (reset && upload && !upload_seen) fifo[write_ptr] <= received_byte;
    end

    always @* begin
        case (dl)
            2'b00: received_byte = {3'b000, shift_data[7:3]};
            2'b01: received_byte = {2'b00, shift_data[7:2]};
            2'b10: received_byte = {1'b0, shift_data[7:1]};
            default: received_byte = shift_data;
        endcase
    end

    // Store each upload once; keep the output valid until rx_r acknowledges it.
    always @(negedge clk or negedge reset) begin
        if (!reset) begin
            read_ptr <= 0;
            write_ptr <= 0;
            rx_bbn <= 0;
            data_ready <= 1'b0;
            parity_error <= 1'b0;
            overrun <= 1'b0;
            upload_seen <= 1'b0;
        end else begin
            upload_seen <= upload;
            if (upload && !upload_seen) begin
                write_ptr <= (write_ptr == LAST) ? {PTR_W{1'b0}} : write_ptr + 1'b1;
                rx_bbn <= rx_bbn + 1'b1;
            end else if (rx_bbn != 0 && !data_ready) begin
                rxds <= fifo[read_ptr];
                parity_error <= parity_errors[read_ptr];
                overrun <= overruns[read_ptr];
                data_ready <= 1'b1;
                read_ptr <= (read_ptr == LAST) ? {PTR_W{1'b0}} : read_ptr + 1'b1;
            end else if (rx_r) begin
                data_ready <= 1'b0;
                rx_bbn <= rx_bbn - 1'b1;
            end
        end
    end

    // Preserve the original idle/receive clock selection and sampling phase.
    always @(negedge receive_clock or negedge reset) begin
        if (!reset) begin
            state <= IDLE;
            parity_errors <= 0;
            overruns <= 0;
            upload <= 1'b0;
        end else if (upload_seen) begin
            upload <= 1'b0;
        end else if (state == IDLE) begin
            if (!rd) begin
                state <= RECEIVE;
                half_bit <= 1'b1;
                parity_bit <= parityn[0];
            end
            bit_count <= 4'd0;
        end else if (state == WAIT_HIGH) begin
            state <= rd ? IDLE : WAIT_HIGH;
        end else begin
            half_bit <= ~half_bit;
            if (half_bit) begin
                if (bit_count == frame_bits) begin
                    upload <= 1'b1;
                    overruns[write_ptr] <= (rx_bbn > txrd_buff + 1);
                    if (parityn[2]) begin
                        if (rd != parity_bit) parity_errors[write_ptr] <= 1'b1;
                        state <= WAIT_HIGH;
                    end else begin
                        state <= IDLE;
                    end
                end else begin
                    shift_data <= {rd, shift_data[7:1]};
                    if (!parityn[1]) parity_bit <= parity_bit ^ rd;
                    bit_count <= bit_count + 1'b1;
                end
            end
        end
    end
endmodule
