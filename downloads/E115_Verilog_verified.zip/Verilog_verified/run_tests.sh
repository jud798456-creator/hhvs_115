#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
for bench in tb_keypad tb_uart; do
    iverilog -g2005 -Wall -s "$bench" -o "build/$bench.vvp" E115_uart_keypad_fixed.v "tests/$bench.v"
    vvp "build/$bench.vvp" +vcd
done
