@echo off
cd /d "%~dp0"
if not exist build mkdir build
iverilog -g2005 -Wall -s tb_keypad -o build/tb_keypad.vvp E115_uart_keypad_fixed.v tests/tb_keypad.v
if errorlevel 1 exit /b 1
vvp build/tb_keypad.vvp +vcd
if errorlevel 1 exit /b 1
iverilog -g2005 -Wall -s tb_uart -o build/tb_uart.vvp E115_uart_keypad_fixed.v tests/tb_uart.v
if errorlevel 1 exit /b 1
vvp build/tb_uart.vvp +vcd
if errorlevel 1 exit /b 1
